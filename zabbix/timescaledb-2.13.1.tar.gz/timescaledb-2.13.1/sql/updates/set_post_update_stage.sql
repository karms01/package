set timescaledb.update_script_stage = 'post';
